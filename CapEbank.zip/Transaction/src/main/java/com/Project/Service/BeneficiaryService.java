package com.Project.Service;



import java.util.List;

import com.Project.Entity.BeneficiaryEntity;




public interface BeneficiaryService {
	
	public BeneficiaryEntity addBeneficiary(BeneficiaryEntity beneficiaryEntity);
	public List<BeneficiaryEntity> getAll();
	public BeneficiaryEntity getOne(Integer custId);
	public List<BeneficiaryEntity> findBenef(Integer accNo);
	//public List<BeneficiaryEntity> getByAcNo(Integer acNo); 
	
}
