package com.Project.Service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.Entity.BeneficiaryEntity;
import com.Project.Repository.BeneficiaryRepository;




@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {

	@Autowired
	private BeneficiaryRepository beneficiaryRepository;
	
//	@Autowired
//	private BankClient bankClient;

	@Override
	public BeneficiaryEntity addBeneficiary(BeneficiaryEntity beneficiaryEntity) {
		return beneficiaryRepository.save(beneficiaryEntity);
	}

	@Override
	public List<BeneficiaryEntity> getAll() {
		return beneficiaryRepository.findAll();
	}
	@Override
	public List<BeneficiaryEntity> findBenef(Integer accNo){
		return beneficiaryRepository.findByaccNo(accNo);
		
	}

	@Override
	public BeneficiaryEntity getOne(Integer slNo) {
		Optional<BeneficiaryEntity> optional= beneficiaryRepository.findById(slNo);
		if(optional.isPresent()){
			return optional.get();
		}else {
			return null;
		}
	}
	
	
}

