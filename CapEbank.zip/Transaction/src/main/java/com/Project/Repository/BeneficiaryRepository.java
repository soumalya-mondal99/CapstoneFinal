package com.Project.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Project.Entity.BeneficiaryEntity;


@Repository
public interface BeneficiaryRepository extends JpaRepository<BeneficiaryEntity, Integer>{
	List<BeneficiaryEntity> findByslNo(Integer slNo);
	List<BeneficiaryEntity> findByaccNo(Integer accNo);
}
