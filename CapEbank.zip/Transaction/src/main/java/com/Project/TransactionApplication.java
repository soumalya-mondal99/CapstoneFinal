package com.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.Project.Entity.BeneficiaryEntity;
import com.Project.Service.BeneficiaryService;

@SpringBootApplication
public class TransactionApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(TransactionApplication.class, args);
		BeneficiaryService service = context.getBean(BeneficiaryService.class);
		service.addBeneficiary(new BeneficiaryEntity(1,1,2,"Sudipto Sasmal","savings","sudip@gmail"));
		service.addBeneficiary(new BeneficiaryEntity(2,1,3,"Rupa Kumari Yadav","savings","rupa@gmail"));
		service.addBeneficiary(new BeneficiaryEntity(3,3,5,"Tridhara Banarjee","savings","tri@gmail"));
		service.addBeneficiary(new BeneficiaryEntity(4,4,1,"Soumalya Mondal","savings","sou@gmail"));
		service.addBeneficiary(new BeneficiaryEntity(5,4,2,"Sudipto Sasmal","savings","sudip@gmail"));


		
	}

}
