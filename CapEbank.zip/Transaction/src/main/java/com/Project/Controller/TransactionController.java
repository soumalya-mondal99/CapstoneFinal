package com.Project.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.Entity.BeneficiaryEntity;
import com.Project.Service.BeneficiaryService;



@CrossOrigin
@RestController
@RequestMapping("/beneficiary")
public class TransactionController {
	
	@Autowired
	private BeneficiaryService beneficiaryService;
	
	@PostMapping
	public BeneficiaryEntity create(@RequestBody BeneficiaryEntity beneficiaryEntity ) {
		return beneficiaryService.addBeneficiary(beneficiaryEntity );
	}
	
	@GetMapping
	public List<BeneficiaryEntity> getAll(){
		return beneficiaryService.getAll();
	}
	
	@GetMapping("/byslno/{slNo}")
	public BeneficiaryEntity getOne(@PathVariable Integer slNo) {
		
		return beneficiaryService.getOne(slNo);
	}
	@GetMapping("/benef/{accNo}")
	public List<BeneficiaryEntity> getBenef(@PathVariable Integer accNo){
		return beneficiaryService.findBenef(accNo);
	}
	
	
	
		
		
	
}
