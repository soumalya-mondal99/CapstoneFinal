package com.proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.proj.entity.Account;
import com.proj.service.AccountService;

@SpringBootApplication
@CrossOrigin
public class EbsAccountApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(EbsAccountApplication.class, args);
		AccountService service = context.getBean(AccountService.class);
		service.createAccount(new Account(1,1,"savings",1000));
		service.createAccount(new Account(2,2,"savings",2000));
		service.createAccount(new Account(3,3,"savings",10000));
		service.createAccount(new Account(4,4,"savings",11000));
		service.createAccount(new Account(5,5,"savings",9000));
		service.createAccount(new Account(6,5,"savings",1000));
		
	}

}
