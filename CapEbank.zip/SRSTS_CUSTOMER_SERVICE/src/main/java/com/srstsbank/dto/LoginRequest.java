package com.srstsbank.dto;

import lombok.Data;

@Data
public class LoginRequest {
	private Integer custId;
	private String password;

}
