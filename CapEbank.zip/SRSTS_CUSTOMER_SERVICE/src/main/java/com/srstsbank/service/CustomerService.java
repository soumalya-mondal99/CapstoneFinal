package com.srstsbank.service;

import java.util.Optional;

import com.srstsbank.dto.ProfileDTO;
import com.srstsbank.entity.CustomerEntity;


public interface CustomerService {
	
	CustomerEntity create(CustomerEntity customerEntity);
	//CustomerEntity findByUsername(String name);
	CustomerEntity findByUserId(Integer custId);
	boolean findByCustId(Integer custId);
	//boolean authenticate(String name, String password);
	boolean authenticate(Integer custId, String password);
	public String updateProfile(Integer custId, ProfileDTO profileDTO);

}
