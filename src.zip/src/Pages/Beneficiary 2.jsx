import React, { useState, useEffect } from 'react';

export default function ViewBeneficiaries() {
  // var temp=props.accNo;
  const [beneficiary, setBeneficiary]= useState([]);
  const [addBenef, setAddBenef] = useState({ accNo: 0, benNo:0,  name: "" ,acType:"",email:""});
  const callBenefAdd = (e) => {
    fetch("http://localhost:2224/beneficiary", {
      method: "POST",
     
      body: JSON.stringify(addBenef),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    })
      .then((response) => response.text())
      .then((data) => {
        console.log(data);
        // setServerMessage(data);
      });
  };
  const updateBenfDet = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    setAddBenef((values) => ({ ...values, [kk]: val }));
  };
  

 
    const callBenef=() => {
      fetch("http://localhost:2224/beneficiary", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.table(data);
          setBeneficiary(data);
        });
    };
    function combineBenef(){
      callBenefAdd();
      callBenef();
      callBenef();
    }

    useEffect(()=>{
      callBenef()
      },[])
  return (
    <div style={{border:'1px solid black',backgroundColor:'lightgoldenrodyellow'}}>
      <h2>Beneficiary Details</h2>
      <table border={3} bgcolor='Aquamarine' align='center'>
          <thead>
            <tr>
              <td>A/C_NO</td>
              <td>Benef acNo</td>
              <td>A/C Type</td>
              <td>Name</td>
              <td>Email</td>
            </tr>
          </thead>
        
        <tbody>
          {beneficiary.map((p, index) => (
            <tr key={index}>
              <td>{p.accNo}</td>
              <td>{p.benNo}</td>
              <td>{p.acType}</td>
              <td>{p.name}</td>
              <td>{p.email}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* <div style={{display: "block",}}> */}
      <div id="add" style={{border: "solid black 1px",backgroundColor:"Aqua"}}>
        <br/>
        <h3>Add Beneficiary</h3>
        <label>Your A/C No : 
        <input
          type="number"
          value={addBenef.accNo}
          onChange={updateBenfDet}
          name="accNo"/></label><br/>
          <br/>

        <label>Beneficiary A/C No. : 
        <input
          type="number"
          value={addBenef.benNo}
          onChange={updateBenfDet}
          name="benNo"/></label><br/>
          <br/>

        <label>Beneficiary Name : 
        <input
          type="text"
          value={addBenef.name}
          onChange={updateBenfDet}
          name="name"/></label><br/>
          <br/>
        
        <label>Beneficiary A/C Type : 
        <input
          type="text"
          defaultValue={addBenef.acType}
          onChange={updateBenfDet}
          name="acType"/></label><br/>
          <br/>

        <label>Beneficiary Email : 
        <input
          type="text"
          value={addBenef.e}
          onChange={updateBenfDet}
          name="email"/></label><br/>
        <span></span><br/>
        <br/>
        <button style={{backgroundColor:'yellow'}} onClick={combineBenef}>Save</button>
     
      </div>
 
    </div>
  );
}

