import { Outlet, Link } from "react-router-dom";

function Layout ()  {
  return (
    <>
      <nav>
        
          <button><Link to="/">Home</Link></button>
            
          
        
      </nav>

      <Outlet />
    </>
  );
}
 export default Layout;