import React, { useEffect, useState } from 'react';

export default function FundTransfer(props) {
  const[tp1, setTp]=useState(0);
    var temp=props.custid
    const [sourceAccount, setSourceAccount] = useState(0);
    const [destinationAccount, setDestinationAccount] = useState(0);
    // const [amount, setAmount] = useState(0);
    // const [transactionPassword, setTransactionPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [accounts, setAccounts]= useState([]);
    const [amount, setAmount] = useState({rs:0});
    /////
 
   

    
    ///
    const callAllAccount = () => {
      if(temp){
      fetch("http://localhost:2223/accounts/allaccount/"+temp, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data != []){
            console.table(data);
            setAccounts(data);
            console.log(accounts)
          }else {console.log("superman")}
        }).catch(error => console.log("error"));}
    }
    useEffect(()=>{
      callAllAccount()

      },[temp])
    // const callAllAccount = (tp) => {
    //   // e.preventDefault();
    //   fetch("http://localhost:2223/accounts/allaccount/"+tp, {
    
    //     method: "GET",
    //     headers: {
    //       "Content-Type": "application/json",
    //       "Access-Control-Allow-Origin": "*",
    //     },
    //   })
    //     .then((response) => response.json())
    //     .then((data) => {
    //       if (data != []){
    //         console.table(data);
    //         setAccounts(data);
    //         console.log(accounts)
    //       }else {console.log("superman")}
    //     }).catch(error => console.log("error"));
    // }

    function callCredit(e,ammount) {

      
      fetch("http://localhost:2223/accounts/update/"+e+"?ammount="+ammount, {

      method: "PUT",
      body: JSON.stringify(ammount),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    }).then((response) => response.text())

    .then((data) => {
      if(data ==1){
        alert("Rs "+ammount*-1+" debited from your account")
        callAllAccount();

      }else if(data ==0){
        alert("insufficient balance in your account");
        
      }else{
        // alert("Rs "+ammount+" credited in your account")
        // callAllAccount();
      }
      //console.log("transc"+data)
    }).catch(error => console.log("error"));
    }
    // function combineBenef(){
    //   callBenefAdd();
    //   callBenef();
    //   callBenef();
    // }

    function callTransfer(e,f,ammount){
      callCredit(e,-ammount);
        callCredit(f,ammount);
      
    }

    const updateAmount = (e) => {
      const kk = e.target.name;
      const val = e.target.value;
      console.log(kk + " : " + val);
      setAmount((values) => ({ ...values, [kk]: val }));
    };


    // const handleTransfer = () => {
    //   // Validate input fields
    //   if (!sourceAccount || !destinationAccount || !amount || !transactionPassword) {
    //     setErrorMessage('Please fill in all fields');
    //     return;
    //   }
    //   // Perform fund transfer logic here
    //   // For demonstration, just log the transfer details
    //   console.log('Transfer details:');
    //   console.log('Source Account:', sourceAccount);
    //   console.log('Destination Account:', destinationAccount);
    //   console.log('Amount:', amount);
    //   console.log('Transaction Password:', transactionPassword);
    //   // Reset input fields and error message
    //   // setSourceAccount('');
    //   // setDestinationAccount('');
    //   // setAmount('');
    //   // setTransactionPassword('');
    //   // setErrorMessage('');
    // };
  return (
    <div style={{border:'1px solid black',backgroundColor:'palegoldenrod'}}>
      <h2>Fund Transfer</h2>
     {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
     <label>Destination Account Number:
     <input type="number" value={destinationAccount} onChange={(e) => setDestinationAccount(e.target.value)}/>
     </label><br/>
     <label>Enter Amount:
     <input type="number" id="inputbox" value={amount.rs} name="rs" onChange={updateAmount} 
                onKeyDown={(e)=>['-','e','+','*','/','E'].includes(e.key) && e.preventDefault()}/>
     </label>
     <br/>
     <br/>
     <table style={{border: '1px solid black',tableLayout: 'fixed',backgroundColor:'palegreen',alignContent:'center'} }>
            {/* <tbody>
            <tr><td>Destination Account Number:</td>
            <td><input type="number" value={destinationAccount} onChange={(e) => setDestinationAccount(e.target.value)}/></td></tr>
            <tr><td>
            Enter Amount</td>
            <td><input type="number" id="inputbox" value={amount.rs} name="rs" onChange={updateAmount} 
                onKeyDown={(e)=>['-','e','+','*','/','E'].includes(e.key) && e.preventDefault()}/></td></tr></tbody> */}
            
            <thead><tr>
              <th >Account No</th><th>Balance</th><th>Transfer</th>
            </tr></thead>
            <tbody>
            {accounts.map((p, index) => (
                <tr key={index}><td>{p.accountid}</td><td>{p.balance}</td>
                <td><button style={{backgroundColor:'cyan'}} onClick={(e)=>callTransfer(p.accountid,destinationAccount,amount.rs)}>Transfer</button></td>

                <td></td></tr>

            ))}

            </tbody>
            </table>
{/* <label>
       Source Account Number:
<input
         type="number"
         value={sourceAccount}
         onChange={(e) => setSourceAccount(e.target.value)}
       />
</label>
<br />

<br />
<label>
       Amount to Transfer:
<input
         type="number"
         value={amount}
         onChange={(e) => setAmount(e.target.value)}
       />
</label>
<br /> */}
{/* <label>
       Transaction Password:
<input
         type="password"
         value={transactionPassword}
         onChange={(e) => setTransactionPassword(e.target.value)}
       />
</label> */}
{/* <br />
<button onClick={(e)=>callTransfer(sourceAccount,destinationAccount,amount)}>Transfer</button> */}
    </div>
  )
  
}
