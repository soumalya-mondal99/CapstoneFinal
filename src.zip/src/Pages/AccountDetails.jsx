import { useEffect, useState } from "react";
import { redirect } from "react-router-dom";
import FundTransfer from "./FundTransfer";
import UpdateProfile from "./UpdateProfile";
import ViewBeneficiaries from "./Beneficiary 2";


function AccountDetails(props){
  const [amount, setAmount] = useState({rs:0});
  // const [tp, setTp] = useState();
  function logOut(){
    window.location.reload(false)
  }
  
    var temp=props.custid
    var temp2=props.name
    console.log(temp2)
    const [accounts, setAccounts]= useState([]);
    var url="http://localhost:2223/accounts/allaccount/"+temp;
    console.log(url)
    
    useEffect(()=>{
      callAllAccount()

      },[temp])
/////
    const callAllAccount = () => {
        if(temp){
        fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data != []){
              console.table(data);
              setAccounts(data);
              console.log(accounts)
            }else {console.log("superman")}
          }).catch(error => console.log("error"));}
      }
  
      ////++++///
      const callCredit = (e,ammount) => {
        fetch("http://localhost:2223/accounts/update/"+e+"?ammount="+ammount, {
        method: "PUT",
        body: JSON.stringify(ammount),
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      }).then((response) => response.text())
      .then((data) => {
        if(data ==1){
          alert("Rs "+ammount*-1+" debited from your account")
          callAllAccount();
        }else if(data ==0){
          alert("insufficient balance in your account")
        }else{
          alert("Rs "+ammount+" credited in your account")
          callAllAccount();
        }
        //console.log("transc"+data)
      }).catch(error => console.log("error"));

      }
      function myAccount(){
        document.getElementById("accountDetails").style.display="block"
        callAllAccount();
        document.getElementById("updateProfile").style.display="none"
        document.getElementById("fundTransfer").style.display="none"
        document.getElementById("benef").style.display="none"
      }

      function updateProfile(){
        document.getElementById("accountDetails").style.display="none"
        document.getElementById("updateProfile").style.display="block"
        document.getElementById("fundTransfer").style.display="none"
        document.getElementById("benef").style.display="none"
      }
      function fundTransfer(){
        document.getElementById("accountDetails").style.display="none"
        document.getElementById("updateProfile").style.display="none"
        document.getElementById("fundTransfer").style.display="block"
        document.getElementById("benef").style.display="none"

      }
      function benefView(){
        document.getElementById("accountDetails").style.display="none"
        document.getElementById("updateProfile").style.display="none"
        document.getElementById("fundTransfer").style.display="none"
        document.getElementById("benef").style.display="block"

      }

      // logout(){
      //   localStorage.clear();
      //   console.log('logged out')
      //   return(
      //     <re
      //   )
      // }
     

      const updateAmount = (e) => {
        const kk = e.target.name;
        const val = e.target.value;
        console.log(kk + " : " + val);
        setAmount((values) => ({ ...values, [kk]: val }));
      };
      // const updateTp = (e) => {
      //   const kk = e.target.name;
      //   const val = e.target.value;
      //   console.log(kk + " : " + val);
      //   setTp((values) => ({ ...values, [kk]: val }));
      // };

    

    return (
        <div >
          <div>
          <button style={{backgroundColor:'cyan' ,border:'1px solid black'}} onClick={myAccount}>My Account</button>&nbsp;
            <button style={{backgroundColor:'cyan' ,border:'1px solid black'}} onClick={updateProfile}>Update Profile</button>&nbsp;
            <button style={{backgroundColor:'cyan' ,border:'1px solid black'}} onClick={fundTransfer}>Fund Transfer</button>&nbsp;
            <button style={{backgroundColor:'cyan' ,border:'1px solid black'}} onClick={benefView}>Beneficiery</button>&nbsp;
            <br></br>

          </div>
            <div id="accountDetails" style={{display:'none',border:'1px solid black', alignItems: 'center',backgroundColor:'gold'}}>
              <h2>My Accounts</h2>
              <table style={{border: '1px solid black',tableLayout: 'fixed'}}><thead><tr>
                <th >Account No</th><th>Type</th><th>Balance</th><th>Credit</th><th>Debit</th>
              </tr></thead>
              <tbody>
              {accounts.map((p, index) => (
                  <tr key={index}><td>{p.accountid}</td><td>{p.accountType}</td><td>{p.balance}</td>
                  <td><button style={{backgroundColor:"cyan"}} onClick={(e)=>callCredit(p.accountid,amount.rs)}>cr</button></td>
                  <td><button style={{backgroundColor:"cyan"}} onClick={(e)=>callCredit(p.accountid,(-amount.rs))}>db</button></td></tr>
              ))}
              
              </tbody>
              <tbody>
              <tr><td>Enter Amount for Db/Cr:</td>
              <td><input type="number" id="inputbox" value={amount.rs} name="rs" onChange={updateAmount} 
                  onKeyDown={(e)=>['-','e','+','*','/','E'].includes(e.key) && e.preventDefault()}/></td></tr>
                
                  </tbody>
              </table>
            </div>
            <section><br /></section>
            {/* {console.log(amount)} */}
            {/* <button><redirect link ="/Home"/>logout</button> */}
            <div id="benef" style={{display:'none'}}><ViewBeneficiaries/></div>
            <div id='fundTransfer' style={{display:'none'}}><FundTransfer custid={temp}/></div>
            <div id='updateProfile' style={{display:'none'}}><UpdateProfile custid={temp}/></div>
            <br/>
            <br/>
            <br/>
            <div><button style={{backgroundColor:'cyan'}} onClick={logOut}>Logout</button></div>
      
      

        </div>
    
    
    );
  }
  
  export default AccountDetails;