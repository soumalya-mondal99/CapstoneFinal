import { useState } from "react";

function UpdateProfile(props){
    var temp=props.custid 

    const [key, setKey]=useState({ password: "", email: "", phno:""})

    const callUpdate = () => {
        // e.preventDefault();
        fetch("http://localhost:2222/customer/profile/"+temp, {
        // mode:"no-cors",
        method: "PUT",
        body: JSON.stringify(key),
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
          .then((response) => response.text())
          .then((data) => {
            alert(data)
            // if (data != []){
            //   console.table(data);
            // //   setAccounts(data);
            // //   console.log(accounts)
            // }else {console.log("superman")}
          }).catch(e => console.log("done"));}
      



  const updateEmail = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    console.log(kk + " : " + val);
    setKey((values) => ({ ...values, [kk]: val }));
  };
  
  const updatePassword = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    console.log(kk + " : " + val);
    setKey((values) => ({ ...values, [kk]: val }));
  };
  const updatePhno = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    console.log(kk + " : " + val);
    setKey((values) => ({ ...values, [kk]: val }));
  };


    return(
        <div style={{border:'1px solid black',backgroundColor:'lightpink'}}>
            <h3>Update Profile</h3>
            <div>
            {/* <form onSubmit={console.log(key.email)} > */}
            <label>
                New Password :
            <input
           type="password"
           value={key.password}
            onChange={updatePassword}
           name="password"/>
</label>
<br />
<br/>
<label>
         New Email :
<input
           type="text"
           value={key.email}
           onChange={updateEmail}
           name="email"
         />
</label>
<br />
<br/>
<label>
         New Phone No :
<input
           type="text"
           value={key.phno}
           onChange={updatePhno}
           name="phno"
         />
</label>
{/* <button type="submit">Update</button> */}
<br/>
<br/>
<button style={{backgroundColor:'lightseagreen'}} onClick={callUpdate}>Update</button>

{/* <button>Update Profile</button> */}
{/* </form> */}</div>




        </div>
    )
}



export default UpdateProfile;