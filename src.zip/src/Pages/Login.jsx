import React, { useState } from 'react';
// import FundTransfer from './FundTransfer';
// import TransactionDetails from './Transaction';
// import ViewAccountStatement from './ViewAccountStatement';
import AccountDetails from './AccountDetails';


export default function Login() {
  const [key, setKey] = useState({ custId: 0, password: ""});
  const [errorMessage, setErrorMessage] = useState('');

  const [name, setName]= useState(null);
  const [email, setEmail]= useState(null);
  const [phno, setPhno]= useState(null);

 


 const callAuthenticate = (e) => {
  e.preventDefault();
  fetch("http://localhost:2222/customer/login", {
    method: "POST",
    body: JSON.stringify(key),
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      console.table(data);
      setName(data.name);
      setEmail(data.email);
      setPhno(data.phno);
      // console.log(data)
      if (data != []){
        console.log("aaaaa")
        
        console.log(key.custId)
        successful();
        
       }else {
        setErrorMessage('enter valid userid and password')
        console.log("error login")
       }
      
      setServerMessage(data);
    }).catch(error => console.log(errorMessage));
 
};
///
const updateId = (e) => {
  const kk = e.target.name;
  const val = e.target.value;
  console.log(kk + " : " + val);
  setKey((values) => ({ ...values, [kk]: val }));
};

const updatePassword = (e) => {
  const kk = e.target.name;
  const val = e.target.value;
  console.log(kk + " : " + val);
  setKey((values) => ({ ...values, [kk]: val }));
};
////
function successful(){
  document.getElementById("login").style.display="none"
  document.getElementById("mainApp").style.display="block"
  console.log(result)
  
}


  return (
    <div>
    <div id='login' style={{display:'block',border:'1px solid black'}}>
      <h2>Login</h2>
     {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
<form onSubmit={callAuthenticate} >
<label>
         UserId:
<input
           type="number"
           value={key.custId}
           onChange={updateId}
           name="custId"
         />
</label>
<br />
<br/>
<label>
         Password:
<input
           type="password"
           value={key.password}
           onChange={updatePassword}
           name="password"
         />
</label>
<br />
<br/>
<button style={{backgroundColor:'cyan'}} type="submit">Login</button>
{/* <button>Update Profile</button> */}
</form> 
    </div>
    {/* <div>
    {result.map((p, index) => (<p key={index}>{p.name}</p>
            ))}

            </div> */}

  
    <div id='mainApp' style={{display:'none'}}>
      <div>
        <section><b>User : </b><>{name}</></section>
        <section><b>Email : </b><>{email}</></section>
        <section><b>Phone No : </b><>{phno}</></section>
      </div>
      {/* <p>{result.name}</p> */}
      <AccountDetails custid={key.custId}/>
      
      {/* <TransactionDetails/>
      <ViewAccountStatement/> */}

    </div>
    

   
    </div>
  );
}




